import React, { useEffect, useMemo, useState } from "react";
import {
  BookOpen, Camera, Heart, Home, LogIn, LogOut, MessageCircle,
  PlayCircle, Plus, ShieldCheck, UserRound, Wallet, X, Image as ImageIcon
} from "lucide-react";
import { supabase } from "./supabase";

const BUCKET = "app-media";

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [posts, setPosts] = useState([]);
  const [likes, setLikes] = useState({});
  const [comments, setComments] = useState({});
  const [commentDraft, setCommentDraft] = useState({});
  const [mode, setMode] = useState("login");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [activeTab, setActiveTab] = useState("home");
  const [postTitle, setPostTitle] = useState("");
  const [postBody, setPostBody] = useState("");
  const [mediaFile, setMediaFile] = useState(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session || !supabase) {
      setProfile(null); setIsAdmin(false); setPosts([]); return;
    }
    loadProfile();
    checkAdmin();
    loadPosts();
  }, [session]);

  async function loadProfile() {
    const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
    setProfile(data);
  }

  async function checkAdmin() {
    const { data, error } = await supabase.rpc("is_app_admin");
    setIsAdmin(!error && data === true);
  }

  async function loadPosts() {
    const { data, error } = await supabase.from("posts")
      .select("id,title,body,media_path,media_type,created_at,created_by")
      .eq("published", true).order("created_at", { ascending: false });
    if (error) { setNotice(error.message); return; }
    const rows = data || [];
    const enriched = await Promise.all(rows.map(async p => {
      let mediaUrl = null;
      if (p.media_path) {
        const { data: signed } = await supabase.storage.from(BUCKET).createSignedUrl(p.media_path, 3600);
        mediaUrl = signed?.signedUrl || null;
      }
      return { ...p, mediaUrl };
    }));
    setPosts(enriched);
    const ids = rows.map(p => p.id);
    if (ids.length) {
      const { data: likeRows } = await supabase.from("post_likes").select("post_id,user_id").in("post_id", ids);
      const map = {};
      (likeRows || []).forEach(l => { (map[l.post_id] ||= []).push(l.user_id); });
      setLikes(map);
      const { data: commentRows } = await supabase.from("comments")
        .select("id,post_id,user_id,body,created_at").in("post_id", ids).order("created_at");
      setComments((commentRows || []).reduce((m,c) => { (m[c.post_id] ||= []).push(c); return m; }, {}));
    }
  }

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: authEmail, password: authPassword,
          options: { data: { full_name: fullName } }
        });
        if (error) throw error;
        setNotice("নিবন্ধন সম্পন্ন করার জন্য আপনার ইমেইল যাচাই করুন।");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword });
        if (error) throw error;
      }
    } catch (e) { setNotice(e.message || "কাজটি সম্পন্ন হয়নি।"); }
    finally { setBusy(false); }
  }

  async function signOut() { await supabase.auth.signOut(); setActiveTab("home"); }

  async function toggleLike(postId) {
    const already = (likes[postId] || []).includes(session.user.id);
    const result = already
      ? await supabase.from("post_likes").delete().eq("post_id", postId).eq("user_id", session.user.id)
      : await supabase.from("post_likes").insert({ post_id: postId, user_id: session.user.id });
    if (result.error) setNotice(result.error.message); else loadPosts();
  }

  async function addComment(postId) {
    const body = (commentDraft[postId] || "").trim();
    if (!body) return;
    const { error } = await supabase.from("comments").insert({ post_id: postId, user_id: session.user.id, body });
    if (error) setNotice(error.message);
    else { setCommentDraft(v => ({ ...v, [postId]: "" })); loadPosts(); }
  }

  async function publishPost(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      let mediaPath = null, mediaType = null;
      if (mediaFile) {
        const safeName = mediaFile.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        mediaPath = `${session.user.id}/${Date.now()}-${safeName}`;
        const { error: uploadError } = await supabase.storage.from(BUCKET).upload(mediaPath, mediaFile, { upsert: false });
        if (uploadError) throw uploadError;
        mediaType = mediaFile.type.startsWith("video/") ? "video" : "image";
      }
      const { error } = await supabase.from("posts").insert({
        title: postTitle.trim(), body: postBody.trim(),
        media_path: mediaPath, media_type: mediaType,
        created_by: session.user.id, published: true
      });
      if (error) throw error;
      setPostTitle(""); setPostBody(""); setMediaFile(null);
      setNotice("পোস্ট প্রকাশিত হয়েছে।"); setActiveTab("home"); await loadPosts();
    } catch (e) { setNotice(e.message || "পোস্ট প্রকাশ করা যায়নি।"); }
    finally { setBusy(false); }
  }

  const ready = Boolean(supabase);
  if (!ready) return <SetupNotice />;

  if (!session) return (
    <main className="auth-shell">
      <div className="auth-card">
        <div className="brand-mark">E<span>V</span></div>
        <p className="eyebrow">WELCOME TO</p>
        <h1>Earn & View BD</h1>
        <p className="muted">দেখুন, পড়ুন, শিখুন — এক জায়গায়।</p>
        <div className="auth-switch">
          <button className={mode === "login" ? "selected" : ""} onClick={() => setMode("login")}>লগইন</button>
          <button className={mode === "signup" ? "selected" : ""} onClick={() => setMode("signup")}>নিবন্ধন</button>
        </div>
        <form onSubmit={submitAuth} className="stack">
          {mode === "signup" && <label>আপনার নাম<input value={fullName} onChange={e => setFullName(e.target.value)} required placeholder="পূর্ণ নাম" /></label>}
          <label>ইমেইল<input type="email" value={authEmail} onChange={e => setAuthEmail(e.target.value)} required placeholder="name@example.com" /></label>
          <label>পাসওয়ার্ড<input type="password" value={authPassword} onChange={e => setAuthPassword(e.target.value)} required minLength="8" placeholder="কমপক্ষে ৮ অক্ষর" /></label>
          <button className="primary full" disabled={busy}>{busy ? "অপেক্ষা করুন..." : mode === "login" ? <><LogIn size={18}/> লগইন করুন</> : "অ্যাকাউন্ট তৈরি করুন"}</button>
        </form>
        {notice && <p className="notice">{notice}</p>}
        <p className="tiny">নিরাপদ প্রবেশ • আপনার তথ্য সুরক্ষিত রাখুন</p>
      </div>
    </main>
  );

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand"><div className="brand-mark small">E<span>V</span></div><div><b>Earn & View BD</b><small>দেখুন • পড়ুন • শিখুন</small></div></div>
        <button className="icon-button" onClick={signOut} title="লগআউট"><LogOut size={19}/></button>
      </header>

      <section className="welcome">
        <div><span className="eyebrow light">আপনাকে স্বাগতম</span><h1>{profile?.full_name || session.user.email?.split("@")[0] || "সদস্য"}</h1><p>নতুন কিছু জানুন, ভালো কিছু শেয়ার করুন।</p></div>
        <div className="welcome-icon"><BookOpen size={34}/></div>
      </section>

      {notice && <div className="notice-bar">{notice}<button onClick={() => setNotice("")}><X size={16}/></button></div>}

      <main className="content">
        {activeTab === "home" && <>
          <div className="section-heading"><div><span className="eyebrow">LATEST UPDATES</span><h2>সর্বশেষ পোস্ট</h2></div>{isAdmin && <button className="primary" onClick={() => setActiveTab("create")}><Plus size={17}/> পোস্ট দিন</button>}</div>
          {posts.length === 0 ? <div className="empty"><div className="empty-icon"><ImageIcon size={28}/></div><h3>এখনো কোনো পোস্ট নেই</h3><p>অ্যাডমিন পোস্ট প্রকাশ করলে এখানে দেখা যাবে।</p></div> :
            <div className="feed">{posts.map(post => <article className="post-card" key={post.id}>
              <div className="post-meta"><div className="avatar"><BookOpen size={17}/></div><div><b>Earn & View BD</b><small>{new Date(post.created_at).toLocaleString("bn-BD")}</small></div><span className="verified"><ShieldCheck size={16}/></span></div>
              {post.title && <h3>{post.title}</h3>}
              {post.body && <p className="post-body">{post.body}</p>}
              {post.mediaUrl && (post.media_type === "video" ? <video className="post-media" controls src={post.mediaUrl}/> : <img className="post-media" src={post.mediaUrl} alt={post.title || "পোস্টের ছবি"}/>)}
              <div className="post-actions"><button className={(likes[post.id] || []).includes(session.user.id) ? "liked" : ""} onClick={() => toggleLike(post.id)}><Heart size={18}/> {(likes[post.id] || []).length} পছন্দ</button><span><MessageCircle size={17}/> {(comments[post.id] || []).length} মন্তব্য</span></div>
              <div className="comments">{(comments[post.id] || []).map(c => <p key={c.id}><b>সদস্য</b> {c.body}</p>)}</div>
              <div className="comment-box"><input value={commentDraft[post.id] || ""} onChange={e => setCommentDraft(v => ({...v, [post.id]: e.target.value}))} placeholder="মন্তব্য লিখুন..."/><button onClick={() => addComment(post.id)}>পাঠান</button></div>
            </article>)}</div>}
        </>}

        {activeTab === "create" && isAdmin && <section className="form-card">
          <button className="back-link" onClick={() => setActiveTab("home")}>← ফিরে যান</button>
          <span className="eyebrow">ADMIN STUDIO</span><h2>নতুন পোস্ট প্রকাশ করুন</h2>
          <form className="stack" onSubmit={publishPost}>
            <label>পোস্টের শিরোনাম<input value={postTitle} onChange={e => setPostTitle(e.target.value)} placeholder="একটি সুন্দর শিরোনাম লিখুন"/></label>
            <label>বিস্তারিত<textarea rows="5" value={postBody} onChange={e => setPostBody(e.target.value)} placeholder="আপনার লেখা এখানে লিখুন..."/></label>
            <label className="upload-label"><Camera size={20}/> ছবি বা ভিডিও বেছে নিন<input type="file" accept="image/jpeg,image/png,image/webp,video/mp4" onChange={e => setMediaFile(e.target.files?.[0] || null)}/><small>{mediaFile ? mediaFile.name : "JPG, PNG, WEBP অথবা MP4 • সর্বোচ্চ ৫০ MB"}</small></label>
            <button className="primary full" disabled={busy || (!postTitle.trim() && !postBody.trim() && !mediaFile)}>{busy ? "আপলোড হচ্ছে..." : "পোস্ট প্রকাশ করুন"}</button>
          </form>
        </section>}

        {activeTab === "profile" && <section className="form-card profile-card"><div className="profile-avatar"><UserRound size={34}/></div><h2>{profile?.full_name || "সদস্য"}</h2><p>{session.user.email}</p>{isAdmin && <span className="admin-pill"><ShieldCheck size={15}/> অ্যাডমিন</span>}<button className="secondary full" onClick={signOut}><LogOut size={17}/> লগআউট</button></section>}

        {activeTab === "wallet" && <section className="form-card"><div className="wallet-icon"><Wallet size={30}/></div><h2>রিওয়ার্ড ও ওয়ালেট</h2><p className="muted">রিওয়ার্ড ও উত্তোলন সুবিধা চালুর আগে প্রকৃত স্পনসর-আয়, নীতিমালা এবং পেমেন্ট যাচাই সম্পন্ন করতে হবে।</p><div className="wallet-placeholder"><b>৳ ০.০০</b><small>পরীক্ষামূলক ব্যালেন্স — বাস্তব টাকা নয়</small></div><p className="tiny">এখনো কোনো বাস্তব অর্থ লেনদেন চালু করা হয়নি।</p></section>}
      </main>

      <nav className="bottom-nav">
        <button className={activeTab === "home" ? "active" : ""} onClick={() => setActiveTab("home")}><Home/><small>হোম</small></button>
        <button className={activeTab === "wallet" ? "active" : ""} onClick={() => setActiveTab("wallet")}><Wallet/><small>ওয়ালেট</small></button>
        <button className={activeTab === "profile" ? "active" : ""} onClick={() => setActiveTab("profile")}><UserRound/><small>প্রোফাইল</small></button>
      </nav>
    </div>
  );
}

function SetupNotice() {
  return <main className="auth-shell"><div className="auth-card"><div className="brand-mark">E<span>V</span></div><h1>Earn & View BD</h1><h3>একটি ছোট সেটআপ বাকি</h3><p className="muted">Supabase-এর Project URL এবং anon key যোগ করলে অ্যাপটি সংযুক্ত হবে। README ফাইলে নির্দেশনা আছে।</p></div></main>;
}

export default App;
