# Earn & View BD

বাংলা ভাষার মোবাইল-ফ্রেন্ডলি React + Vite PWA। Supabase Auth, Database ও Storage-এর সঙ্গে যুক্ত।

## এই সংস্করণে
- ইমেইল দিয়ে নিবন্ধন ও লগইন
- পোস্ট ফিড, ছবি/ভিডিও দেখা
- লাইক ও মন্তব্য
- অ্যাডমিন পোস্ট প্রকাশ
- পরীক্ষামূলক ওয়ালেট স্ক্রিন (বাস্তব অর্থ লেনদেন নয়)
- Android Chrome-এ হোম স্ক্রিনে ইনস্টলযোগ্য PWA

## Supabase সংযোগ
এই প্যাকেজে `.env`-এ আপনার আগে তৈরি `earn-view-bd` প্রজেক্টের URL এবং browser-safe `sb_publishable_...` key বসানো আছে। Publishable/anon key ব্রাউজারে ব্যবহারের জন্য; `service_role` বা অন্য কোনো secret key কখনো frontend-এ দেবেন না। `.env` Git-এ commit করবেন না।

Supabase project: `https://qggfyoknssrvhsxhowpr.supabase.co`

অ্যাপটি নিচের বিদ্যমান অবজেক্ট আশা করে:
- `profiles` (`id`, `full_name`, `avatar_url`)
- `posts` (`id`, `title`, `body`, `media_path`, `media_type`, `created_by`, `published`, `created_at`)
- `comments` (`id`, `post_id`, `user_id`, `body`, `created_at`)
- `post_likes` (`post_id`, `user_id`)
- Storage bucket: `app-media`
- RPC: `is_app_admin()`

ডাটাবেসের কলাম, RLS policies এবং Storage policies Dashboard-এ যাচাই না করে বাস্তব ব্যবহারকারীর জন্য চালু করবেন না। অ্যাডমিন অনুমতি অবশ্যই Supabase-এর RLS/policies-এ enforce করতে হবে; শুধু UI-তে অ্যাডমিন বাটন লুকানো নিরাপত্তা নয়।

## Vercel
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- `vercel.json` SPA rewrite সেট করে।

Vercel Drop-এ ZIP upload করলে build-এর সময় `.env` থেকে Vite config পড়ার কথা। যদি Vercel environment variables চায়, Project Settings → Environment Variables-এ `VITE_SUPABASE_URL` এবং `VITE_SUPABASE_ANON_KEY` যোগ করুন। দ্বিতীয়টির মান এই প্যাকেজের `.env`-এ থাকা একই publishable key; secret/service_role key নয়।

## সীমাবদ্ধতা ও নিরাপত্তা
- Wallet এখন demo-only; বাস্তব টাকা, আয়, withdrawal বা AdMob integration নেই।
- বিজ্ঞাপন দেখা/ক্লিকের বিনিময়ে অর্থ দেওয়ার প্রতিশ্রুতি বা invalid traffic তৈরি করবেন না।
- Telegram Mini App/Bot ও Play Store APK/AAB এই web/PWA প্যাকেজে অন্তর্ভুক্ত নয়।
- প্রকাশের আগে Supabase Auth redirect URLs-এ আপনার Vercel domain যোগ করতে হবে।
- Build ও live database integration এই পরিবেশে সম্পূর্ণ end-to-end যাচাই করা যায়নি।
